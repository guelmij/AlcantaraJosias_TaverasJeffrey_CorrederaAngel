-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: tiendadejuego
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `dni_cliente` char(9) NOT NULL,
  `nombre_cliente` varchar(20) NOT NULL,
  `Apellidos` varchar(20) NOT NULL,
  `direccion` varchar(30) NOT NULL,
  `nacionalidad` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`dni_cliente`),
  KEY `idx_nacionalidad` (`nacionalidad` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES ('42183789H','CARLOS	DAVIAD','ABRANTE ALONSO','LAPRIDA 23','Española'),('42873899J','DAVID	MIGUEL','ARENACIBIA','Av FRANCIA 12','ARGENTINO');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras`
--

DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras` (
  `codigo_juego` int NOT NULL,
  `dni_cliente` char(9) NOT NULL,
  `fecha_compra` date NOT NULL,
  PRIMARY KEY (`codigo_juego`,`dni_cliente`),
  KEY `dni_cliente` (`dni_cliente`),
  KEY `idx_fecha_compra` (`fecha_compra` DESC),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`codigo_juego`) REFERENCES `juegos` (`codigo_juego`),
  CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`dni_cliente`) REFERENCES `clientes` (`dni_cliente`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
INSERT INTO `compras` VALUES (4,'42873899J','2021-01-01'),(3,'42183789H','2020-03-05');
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `numss` int NOT NULL,
  `dni_cliente` char(9) NOT NULL,
  `numss_jefe` int NOT NULL,
  `dni_e` char(9) NOT NULL,
  `nombre_e` varchar(20) NOT NULL,
  `apellido_e` varchar(20) NOT NULL,
  `mayor_menor` tinyint(1) DEFAULT NULL,
  `fecha_n` date NOT NULL,
  PRIMARY KEY (`numss`),
  KEY `dni_cliente` (`dni_cliente`),
  CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`dni_cliente`) REFERENCES `clientes` (`dni_cliente`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1234567842,'42873899J',1234567841,'12345673J','LUCIANO','ALCANTARA',1,'1990-06-06'),(1234567899,'42183789H',1234567841,'92345678J','JOSIAS','GOREA',1,'1990-06-06');
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fecha_compra_juego`
--

DROP TABLE IF EXISTS `fecha_compra_juego`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fecha_compra_juego` (
  `codigo` int NOT NULL,
  `fecha_de_compra` date DEFAULT NULL,
  `nombre_juego` varchar(20) DEFAULT NULL,
  `cliente` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fecha_compra_juego`
--

LOCK TABLES `fecha_compra_juego` WRITE;
/*!40000 ALTER TABLE `fecha_compra_juego` DISABLE KEYS */;
INSERT INTO `fecha_compra_juego` VALUES (4,'2021-01-01','The Witcher3','DAVID	MIGUEL');
/*!40000 ALTER TABLE `fecha_compra_juego` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `juegos`
--

DROP TABLE IF EXISTS `juegos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `juegos` (
  `codigo_juego` int NOT NULL AUTO_INCREMENT,
  `nombre_juego` varchar(20) NOT NULL,
  `unidad` int NOT NULL,
  `tipo` enum('Accion','Estrategia','Simulacion','Deportivo','Otros') NOT NULL,
  PRIMARY KEY (`codigo_juego`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `juegos`
--

LOCK TABLES `juegos` WRITE;
/*!40000 ALTER TABLE `juegos` DISABLE KEYS */;
INSERT INTO `juegos` VALUES (1,'DragonBall',45,'Accion'),(2,'Fortnite',12,'Estrategia'),(3,'Raft',120,'Simulacion'),(4,'The Witcher3',20,'Otros'),(5,'2K2021',23,'Deportivo'),(6,'Tetris',3,'Deportivo'),(7,'Sonic',13,'Deportivo');
/*!40000 ALTER TABLE `juegos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `juegosnuevos`
--

DROP TABLE IF EXISTS `juegosnuevos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `juegosnuevos` (
  `codigo_juego` int NOT NULL,
  `formato` enum('Fisico','Digital') NOT NULL,
  PRIMARY KEY (`codigo_juego`),
  CONSTRAINT `juegosnuevos_ibfk_1` FOREIGN KEY (`codigo_juego`) REFERENCES `juegos` (`codigo_juego`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `juegosnuevos`
--

LOCK TABLES `juegosnuevos` WRITE;
/*!40000 ALTER TABLE `juegosnuevos` DISABLE KEYS */;
INSERT INTO `juegosnuevos` VALUES (4,'Fisico'),(5,'Digital'),(6,'Digital'),(7,'Fisico');
/*!40000 ALTER TABLE `juegosnuevos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `juegosusados`
--

DROP TABLE IF EXISTS `juegosusados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `juegosusados` (
  `codigo_juego` int NOT NULL,
  `tiempo` date NOT NULL,
  PRIMARY KEY (`codigo_juego`),
  CONSTRAINT `juegosusados_ibfk_1` FOREIGN KEY (`codigo_juego`) REFERENCES `juegos` (`codigo_juego`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `juegosusados`
--

LOCK TABLES `juegosusados` WRITE;
/*!40000 ALTER TABLE `juegosusados` DISABLE KEYS */;
INSERT INTO `juegosusados` VALUES (1,'2019-02-07'),(2,'2017-03-06'),(3,'2019-06-09');
/*!40000 ALTER TABLE `juegosusados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telefonos`
--

DROP TABLE IF EXISTS `telefonos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telefonos` (
  `numero` char(9) NOT NULL,
  `dni_cliente` char(9) NOT NULL,
  PRIMARY KEY (`numero`),
  KEY `dni_cliente` (`dni_cliente`),
  CONSTRAINT `telefonos_ibfk_1` FOREIGN KEY (`dni_cliente`) REFERENCES `clientes` (`dni_cliente`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telefonos`
--

LOCK TABLES `telefonos` WRITE;
/*!40000 ALTER TABLE `telefonos` DISABLE KEYS */;
INSERT INTO `telefonos` VALUES ('123456789','42183789H');
/*!40000 ALTER TABLE `telefonos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tienda`
--

DROP TABLE IF EXISTS `tienda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tienda` (
  `código_tienda` int NOT NULL,
  `direccion_tienda` varchar(30) NOT NULL,
  `nombre_tienda` varchar(20) NOT NULL,
  `numss` int NOT NULL,
  PRIMARY KEY (`código_tienda`),
  KEY `numss` (`numss`),
  CONSTRAINT `tienda_ibfk_1` FOREIGN KEY (`numss`) REFERENCES `empleados` (`numss`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tienda`
--

LOCK TABLES `tienda` WRITE;
/*!40000 ALTER TABLE `tienda` DISABLE KEYS */;
INSERT INTO `tienda` VALUES (1110,'Leganes','LUCIANOGAM',1234567842),(1120,'Madrid','JOSIASGAME',1234567899);
/*!40000 ALTER TABLE `tienda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tiendadejuego'
--
/*!50003 DROP FUNCTION IF EXISTS `cod_juego` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `cod_juego`(cod_juego int(4)) RETURNS varchar(50) CHARSET utf8mb4
    DETERMINISTIC
begin
-- Nos interesa crear una función que al ingresar el código de un videojuego
-- nos devuelva una cadena si el juego es usado, si es nuevo o si el ID 
-- introtroducido es inválido. 

	if cod_juego in (select codigo_juego from Juegosnuevos) then
		return "Es un juego nuevo";
	elseif cod_juego in (select codigo_juego from Juegosusados) then
		return "Es un juego usado";
	elseif cod_juego < 1 or cod_juego > 7 then
		signal sqlstate "45000" set message_text = "ID incorrecto";
	end if;
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `fecha_compra` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fecha_compra`(IN DNICliente varchar(20))
begin
-- Procedimiento que recibe el dni de un cliente y nos devuelve 
-- el código del juego, la fecha de compra, el nombre del juego y el nombre del cliente.

	DECLARE fin INT DEFAULT 0;
	DECLARE aux_cod_juego INT;
    DECLARE aux_fecha date;
    DECLARE aux_nombre_cli varchar(50);
    DECLARE aux_nombre_juego varchar(50);
    DECLARE aux_dni char(9) DEFAULT " ";
    
	DECLARE cursor_fecha_C cursor for select codigo_juego, fecha_compra from Compras WHERE dni_cliente=DNICliente;
    DECLARE continue handler for not found set fin = 1; 
	
    select dni_cliente into aux_dni from clientes where dni_cliente=DNICliente;
    
    IF  DNICliente <> aux_dni then
	SIGNAL SQLSTATE "45000" SET MESSAGE_TEXT = "INGRESE UN DNI DE UN CLIENTE VALIDO";
    end IF;
    
    drop table if exists fecha_compra_juego;
			create table fecha_compra_juego (
						codigo int(4) primary key,
						fecha_de_compra date,
						nombre_juego varchar(20), 
						cliente varchar(20) 
                         );
	open cursor_fecha_C;		
	bucle: LOOP
		fetch cursor_fecha_C into aux_cod_juego, aux_fecha;
			if fin then
				leave bucle;
			end if;		
		select nombre_juego INTO aux_nombre_juego from juegos where codigo_juego=aux_cod_juego;
		select nombre_cliente INTO aux_nombre_cli from clientes where dni_cliente=DNICliente;		
        insert into fecha_compra_juego values(aux_cod_juego, aux_fecha, aux_nombre_juego, aux_nombre_cli);		
        end LOOP bucle;
	close cursor_fecha_C;
	select * from  fecha_compra_juego;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tipo_juego` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tipo_juego`(in _tipo varchar(15))
BEGIN
-- Queremos crear un procedimiento que reciba por parámetro la clasificación
-- (Acción, Deportivo, Simulación, Estrategia) de un videojuego y nos devuelva 
-- el nombre, y las unidades del mismo.

-- declarar las variables
declare fin int default 0;
declare aux_unidad int (4) default 0;
declare aux_tipo varchar (15);
declare resultado varchar (100);
declare aux_nombre varchar (50);

-- crear el cursor
declare cursor_juego cursor for select tipo, sum(unidad), nombre_juego from juegos where tipo = _tipo;

-- declarar el handler
declare continue handler for not found set fin = 1;

-- uso del cursor y loop
open cursor_juego;
	loop_lectura: loop
		fetch cursor_juego into aux_tipo, aux_unidad, aux_nombre;
			if fin  	
				then leave loop_lectura;
			end if;
        if aux_tipo = _tipo then 
			set resultado = concat("Tipo de Juego:", " ",aux_tipo," | ", "Cantidad:", "  ", aux_unidad);
        end if;
	end loop loop_lectura;

close cursor_juego;
select resultado;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-13 23:22:40
