CREATE DATABASE TiendadeJuego;
SHOW DATABASES;

USE TiendadeJuego;

/* INSERT INTO */

CREATE TABLE Juegos (
codigo_juego INT(4) PRIMARY KEY AUTO_INCREMENT,
nombre_juego VARCHAR(20) NOT NULL,
unidad INT (10) NOT NULL,
tipo ENUM ('Accion','Estrategia','Simulacion', 'Deportivo','Otros') NOT NULL
);

/* INSERT  INTO */

CREATE TABLE Juegosusados ( /*  En usado no se necesita formato, 
	usado solo puede ser fisico*/
codigo_juego INT(4) PRIMARY KEY,
tiempo DATE NOT NULL, 
FOREIGN KEY (codigo_juego) REFERENCES Juegos(codigo_juego)	
	ON DELETE RESTRICT ON UPDATE RESTRICT
);

/* INSERT  INTO */

CREATE TABLE Juegosnuevos (
codigo_juego INT(4) PRIMARY KEY,
formato ENUM ('Fisico','Digital') NOT NULL, 
FOREIGN KEY (codigo_juego) REFERENCES Juegos(codigo_juego)	
	ON DELETE RESTRICT ON UPDATE RESTRICT
);

/* INSERT INTO */

CREATE TABLE Clientes (
dni_cliente CHAR (9) PRIMARY KEY, 
nombre_cliente VARCHAR(20) NOT NULL,
Apellidos VARCHAR(20) NOT NULL,
direccion VARCHAR(30) NOT NULL,
nacionalidad VARCHAR(10)
);

/* INSERT INTO */

CREATE TABLE Compras (
codigo_juego INT(4),
dni_cliente CHAR (9),
fecha_compra DATE NOT NULL,
PRIMARY KEY (codigo_juego,dni_cliente),
FOREIGN KEY (codigo_juego) REFERENCES Juegos(codigo_juego),
FOREIGN KEY (dni_cliente) REFERENCES Clientes(dni_cliente)
		ON DELETE RESTRICT ON UPDATE CASCADE
);

/* INSERT XML */

CREATE TABLE Telefonos (
numero CHAR(9) PRIMARY KEY,
dni_cliente CHAR(9) NOT NULL,
FOREIGN KEY (dni_cliente) REFERENCES Clientes(dni_cliente)
		ON DELETE RESTRICT ON UPDATE CASCADE 
);

/* INSERT INTO */

CREATE TABLE Empleados (
numss INT(12) PRIMARY KEY,
dni_cliente CHAR(9) NOT NULL,
numss_jefe INT(12) NOT NULL,
dni_e CHAR(9) NOT NULL,
nombre_e VARCHAR(20) NOT NULL,
apellido_e VARCHAR(20) NOT NULL,
mayor_menor BOOLEAN DEFAULT NULL,
fecha_n DATE NOT NULL,
FOREIGN KEY (dni_cliente) REFERENCES Clientes(dni_cliente)
		ON DELETE RESTRICT ON UPDATE CASCADE
);

/* INSERT INTO */

CREATE TABLE Tienda (
código_tienda INT(4) PRIMARY KEY,
direccion_tienda VARCHAR(30) NOT NULL,
nombre_tienda VARCHAR(20) NOT NULL,
numss INT(12) NOT NULL,
FOREIGN KEY (numss) REFERENCES Empleados(numss)
		ON DELETE RESTRICT ON UPDATE CASCADE
);


/*INSERTAR DATOS */

INSERT INTO Juegos VALUES 
(0001, "DragonBall", 45,"Accion"),
(0002, "Fortnite", 12,"Estrategia"),
(0003, "Raft", 120,"Simulacion"),
(0004, "The Witcher3", 20,"Otros"),
(0005, "2K2021", 23,"Deportivo"),
(0006, "Tetris", 3,"Deportivo"),
(0007, "Sonic", 13,"Deportivo");


INSERT INTO Juegosusados VALUES 
(0001, "2019/02/07"),
(0002, "2017/03/06"),
(0003, "2019/06/09");


INSERT INTO Juegosnuevos VALUES 
(004, "Fisico"),
(005, "Digital"),
(006, "Digital"),
(007, "Fisico");

INSERT INTO Clientes VALUES 
("42183789H", "CARLOS	DAVIAD", "ABRANTE ALONSO","LAPRIDA 23","Española"),
("42873899J","DAVID	MIGUEL","ARENACIBIA","Av FRANCIA 12","ARGENTINO");


INSERT INTO Compras VALUES 
(0003,"42183789H", "2020/03/05"),
(0004,"42873899J", "2021/01/01");

Insert INTO  Telefonos VALUES
(123456789, "42183789H");

INSERT INTO Empleados VALUES 
(1234567842, "42873899J", 1234567841, "12345673J", "LUCIANO", "ALCANTARA", "1", "1990/06/06"),
(1234567899, "42183789H", 1234567841, "92345678J", "JOSIAS", "GOREA", "1", "1990/06/06");


INSERT INTO Tienda VALUES 
(1110, "Leganes", "LUCIANOGAM",1234567842),
(1120, "Madrid", "JOSIASGAME",1234567899);
