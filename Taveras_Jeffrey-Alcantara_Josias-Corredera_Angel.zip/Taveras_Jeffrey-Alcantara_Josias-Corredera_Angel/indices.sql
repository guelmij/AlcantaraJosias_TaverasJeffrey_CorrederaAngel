-- Comprobamos plan de ejecución sin índice
EXPLAIN SELECT * FROM clientes WHERE nacionalidad='Española';
-- Creamos índice para saber la nacionalidad del cliente
CREATE INDEX idx_nacionalidad ON Clientes (Nacionalidad DESC);
-- Comprobamos plan de ejecución con índice
EXPLAIN SELECT * FROM clientes WHERE nacionalidad='Española';

-- Comprobamos plan de ejecución sin índice
EXPLAIN SELECT fecha_compra FROM compras;
-- Creamos índice porque es habitual y nos interesa averiguar la fecha de compra de los juegos
CREATE INDEX idx_fecha_compra ON compras (fecha_compra DESC);
-- Comprobamos plan de ejecución con índice
EXPLAIN SELECT fecha_compra FROM compras;
